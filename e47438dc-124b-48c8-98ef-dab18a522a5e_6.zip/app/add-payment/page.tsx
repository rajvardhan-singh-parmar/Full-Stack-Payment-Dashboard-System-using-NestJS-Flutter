
'use client';

import Link from 'next/link';
import { useState } from 'react';

export default function AddPaymentPage() {
  const [formData, setFormData] = useState({
    amount: '',
    receiver: '',
    method: 'Credit Card',
    status: 'success',
    description: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1500));

    setIsSubmitting(false);
    setShowSuccess(true);
    
    // Reset form
    setFormData({
      amount: '',
      receiver: '',
      method: 'Credit Card',
      status: 'success',
      description: ''
    });

    // Hide success message after 3 seconds
    setTimeout(() => setShowSuccess(false), 3000);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="fixed top-0 w-full bg-white shadow-sm z-50 animate-slide-down">
        <div className="px-4 py-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Link href="/" className="w-8 h-8 flex items-center justify-center hover:bg-gray-100 rounded-full transition-all duration-200 transform hover:scale-110">
                <i className="ri-arrow-left-line text-gray-600 text-xl"></i>
              </Link>
              <h1 className="text-xl font-bold text-gray-800">Add Payment</h1>
            </div>
            <button className="w-8 h-8 flex items-center justify-center hover:bg-gray-100 rounded-full transition-all duration-200 transform hover:scale-110">
              <i className="ri-history-line text-gray-600 text-xl"></i>
            </button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="pt-16 pb-20">
        {/* Success Message */}
        {showSuccess && (
          <div className="fixed top-20 left-4 right-4 bg-green-500 text-white rounded-lg p-4 z-50 animate-bounce-in shadow-lg">
            <div className="flex items-center space-x-2">
              <i className="ri-check-line text-xl animate-pulse"></i>
              <span className="font-medium">Payment simulated successfully!</span>
            </div>
          </div>
        )}

        <div className="px-4 py-6">
          {/* Form */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 animate-fade-in-up">
            <div className="p-6">
              <div className="text-center mb-6">
                <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-3 animate-pulse-slow">
                  <i className="ri-money-dollar-circle-line text-blue-600 text-2xl"></i>
                </div>
                <h2 className="text-lg font-semibold text-gray-800 animate-fade-in">Simulate Payment</h2>
                <p className="text-sm text-gray-600 mt-1 animate-fade-in-delay">Create a test payment transaction</p>
              </div>

              <form onSubmit={handleSubmit} className="space-y-6">
                {/* Amount */}
                <div className="animate-slide-in-left" style={{animationDelay: '0.1s'}}>
                  <label htmlFor="amount" className="block text-sm font-medium text-gray-700 mb-2">
                    Amount *
                  </label>
                  <div className="relative">
                    <input
                      id="amount"
                      name="amount"
                      type="number"
                      step="0.01"
                      value={formData.amount}
                      onChange={handleInputChange}
                      className="w-full pl-12 pr-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-300 transform hover:scale-[1.02] focus:scale-[1.02]"
                      placeholder="0.00"
                      required
                    />
                    <div className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 flex items-center justify-center">
                      <i className="ri-money-dollar-circle-line text-gray-400 text-lg transition-colors duration-200"></i>
                    </div>
                  </div>
                </div>

                {/* Receiver */}
                <div className="animate-slide-in-left" style={{animationDelay: '0.2s'}}>
                  <label htmlFor="receiver" className="block text-sm font-medium text-gray-700 mb-2">
                    Receiver *
                  </label>
                  <div className="relative">
                    <input
                      id="receiver"
                      name="receiver"
                      type="text"
                      value={formData.receiver}
                      onChange={handleInputChange}
                      className="w-full pl-12 pr-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-300 transform hover:scale-[1.02] focus:scale-[1.02]"
                      placeholder="Enter receiver name"
                      required
                    />
                    <div className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 flex items-center justify-center">
                      <i className="ri-user-line text-gray-400 text-lg transition-colors duration-200"></i>
                    </div>
                  </div>
                </div>

                {/* Payment Method */}
                <div className="animate-slide-in-left" style={{animationDelay: '0.3s'}}>
                  <label htmlFor="method" className="block text-sm font-medium text-gray-700 mb-2">
                    Payment Method *
                  </label>
                  <div className="relative">
                    <select
                      id="method"
                      name="method"
                      value={formData.method}
                      onChange={handleInputChange}
                      className="w-full pl-12 pr-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent appearance-none transition-all duration-300 transform hover:scale-[1.02] focus:scale-[1.02]"
                      required
                    >
                      <option value="Credit Card">Credit Card</option>
                      <option value="PayPal">PayPal</option>
                      <option value="Bank Transfer">Bank Transfer</option>
                      <option value="Digital Wallet">Digital Wallet</option>
                    </select>
                    <div className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 flex items-center justify-center">
                      <i className="ri-bank-card-line text-gray-400 text-lg transition-colors duration-200"></i>
                    </div>
                    <div className="absolute right-4 top-1/2 transform -translate-y-1/2 w-5 h-5 flex items-center justify-center">
                      <i className="ri-arrow-down-s-line text-gray-400 text-lg transition-transform duration-200"></i>
                    </div>
                  </div>
                </div>

                {/* Status */}
                <div className="animate-slide-in-left" style={{animationDelay: '0.4s'}}>
                  <label htmlFor="status" className="block text-sm font-medium text-gray-700 mb-2">
                    Status *
                  </label>
                  <div className="relative">
                    <select
                      id="status"
                      name="status"
                      value={formData.status}
                      onChange={handleInputChange}
                      className="w-full pl-12 pr-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent appearance-none transition-all duration-300 transform hover:scale-[1.02] focus:scale-[1.02]"
                      required
                    >
                      <option value="success">Success</option>
                      <option value="pending">Pending</option>
                      <option value="failed">Failed</option>
                    </select>
                    <div className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 flex items-center justify-center">
                      <i className="ri-checkbox-circle-line text-gray-400 text-lg transition-colors duration-200"></i>
                    </div>
                    <div className="absolute right-4 top-1/2 transform -translate-y-1/2 w-5 h-5 flex items-center justify-center">
                      <i className="ri-arrow-down-s-line text-gray-400 text-lg transition-transform duration-200"></i>
                    </div>
                  </div>
                </div>

                {/* Description */}
                <div className="animate-slide-in-left" style={{animationDelay: '0.5s'}}>
                  <label htmlFor="description" className="block text-sm font-medium text-gray-700 mb-2">
                    Description (Optional)
                  </label>
                  <textarea
                    id="description"
                    name="description"
                    value={formData.description}
                    onChange={handleInputChange}
                    rows={3}
                    maxLength={500}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none transition-all duration-300 transform hover:scale-[1.02] focus:scale-[1.02]"
                    placeholder="Add a description for this payment..."
                  />
                  <p className="text-xs text-gray-500 mt-1 transition-colors duration-200">{formData.description.length}/500 characters</p>
                </div>

                {/* Submit Button */}
                <div className="animate-slide-in-left" style={{animationDelay: '0.6s'}}>
                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="w-full bg-blue-500 text-white py-3 rounded-lg font-medium hover:bg-blue-600 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed !rounded-button transform hover:scale-[1.02] active:scale-[0.98] shadow-lg hover:shadow-xl"
                  >
                    {isSubmitting ? (
                      <div className="flex items-center justify-center space-x-2">
                        <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                        <span>Processing...</span>
                      </div>
                    ) : (
                      'Simulate Payment'
                    )}
                  </button>
                </div>
              </form>
            </div>
          </div>

          {/* Recent Payments */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 mt-6 animate-fade-in-up" style={{animationDelay: '0.3s'}}>
            <div className="p-4 border-b border-gray-100">
              <h3 className="font-semibold text-gray-800">Recent Simulated Payments</h3>
            </div>
            <div className="p-4">
              <div className="space-y-3">
                <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg transition-all duration-200 hover:bg-gray-100 transform hover:scale-[1.02] animate-slide-in-right" style={{animationDelay: '0.4s'}}>
                  <div className="flex items-center space-x-3">
                    <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center animate-pulse-slow">
                      <i className="ri-check-line text-green-600 text-sm"></i>
                    </div>
                    <div>
                      <p className="font-medium text-gray-800 text-sm">Arjun Sharma</p>
                      <p className="text-xs text-gray-500">Credit Card • 2 min ago</p>
                    </div>
                  </div>
                  <span className="font-semibold text-gray-800">$299.99</span>
                </div>
                <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg transition-all duration-200 hover:bg-gray-100 transform hover:scale-[1.02] animate-slide-in-right" style={{animationDelay: '0.5s'}}>
                  <div className="flex items-center space-x-3">
                    <div className="w-8 h-8 bg-yellow-100 rounded-full flex items-center justify-center animate-pulse-slow">
                      <i className="ri-time-line text-yellow-600 text-sm"></i>
                    </div>
                    <div>
                      <p className="font-medium text-gray-800 text-sm">Priya Patel</p>
                      <p className="text-xs text-gray-500">PayPal • 5 min ago</p>
                    </div>
                  </div>
                  <span className="font-semibold text-gray-800">$150.00</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* Bottom Navigation */}
      <nav className="fixed bottom-0 w-full bg-white border-t border-gray-200 z-50 animate-slide-up">
        <div className="grid grid-cols-4 py-2">
          <Link href="/" className="flex flex-col items-center py-2 text-gray-400 transition-all duration-200 hover:text-blue-500 transform hover:scale-110">
            <div className="w-6 h-6 flex items-center justify-center mb-1">
              <i className="ri-dashboard-line text-xl"></i>
            </div>
            <span className="text-xs">Dashboard</span>
          </Link>
          <Link href="/transactions" className="flex flex-col items-center py-2 text-gray-400 transition-all duration-200 hover:text-blue-500 transform hover:scale-110">
            <div className="w-6 h-6 flex items-center justify-center mb-1">
              <i className="ri-exchange-line text-xl"></i>
            </div>
            <span className="text-xs">Transactions</span>
          </Link>
          <Link href="/users" className="flex flex-col items-center py-2 text-gray-400 transition-all duration-200 hover:text-blue-500 transform hover:scale-110">
            <div className="w-6 h-6 flex items-center justify-center mb-1">
              <i className="ri-user-line text-xl"></i>
            </div>
            <span className="text-xs">Users</span>
          </Link>
          <Link href="/reports" className="flex flex-col items-center py-2 text-gray-400 transition-all duration-200 hover:text-blue-500 transform hover:scale-110">
            <div className="w-6 h-6 flex items-center justify-center mb-1">
              <i className="ri-bar-chart-line text-xl"></i>
            </div>
            <span className="text-xs">Reports</span>
          </Link>
        </div>
      </nav>

      <style jsx>{`
        @keyframes slide-down {
          from {
            transform: translateY(-100%);
            opacity: 0;
          }
          to {
            transform: translateY(0);
            opacity: 1;
          }
        }

        @keyframes slide-up {
          from {
            transform: translateY(100%);
            opacity: 0;
          }
          to {
            transform: translateY(0);
            opacity: 1;
          }
        }

        @keyframes fade-in {
          from {
            opacity: 0;
          }
          to {
            opacity: 1;
          }
        }

        @keyframes fade-in-up {
          from {
            opacity: 0;
            transform: translateY(30px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }

        @keyframes slide-in-left {
          from {
            opacity: 0;
            transform: translateX(-30px);
          }
          to {
            opacity: 1;
            transform: translateX(0);
          }
        }

        @keyframes slide-in-right {
          from {
            opacity: 0;
            transform: translateX(30px);
          }
          to {
            opacity: 1;
            transform: translateX(0);
          }
        }

        @keyframes bounce-in {
          0% {
            transform: translateY(-10px) scale(0.8);
            opacity: 0;
          }
          50% {
            transform: translateY(5px) scale(1.05);
            opacity: 1;
          }
          100% {
            transform: translateY(0) scale(1);
            opacity: 1;
          }
        }

        .animate-slide-down {
          animation: slide-down 0.6s ease-out;
        }

        .animate-slide-up {
          animation: slide-up 0.6s ease-out;
        }

        .animate-fade-in {
          animation: fade-in 0.8s ease-out;
        }

        .animate-fade-in-delay {
          animation: fade-in 0.8s ease-out 0.2s both;
        }

        .animate-fade-in-up {
          animation: fade-in-up 0.8s ease-out both;
        }

        .animate-slide-in-left {
          animation: slide-in-left 0.6s ease-out both;
        }

        .animate-slide-in-right {
          animation: slide-in-right 0.6s ease-out both;
        }

        .animate-bounce-in {
          animation: bounce-in 0.6s ease-out;
        }

        .animate-pulse-slow {
          animation: pulse 3s ease-in-out infinite;
        }

        @keyframes pulse {
          0%, 100% {
            transform: scale(1);
            opacity: 1;
          }
          50% {
            transform: scale(1.05);
            opacity: 0.9;
          }
        }
      `}</style>
    </div>
  );
}
