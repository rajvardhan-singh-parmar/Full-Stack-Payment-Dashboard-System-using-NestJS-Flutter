
'use client';

import Link from 'next/link';
import { useState } from 'react';

export default function Home() {
  const [selectedTab, setSelectedTab] = useState('dashboard');
  const [showSettings, setShowSettings] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);
  const [settings, setSettings] = useState({
    notifications: true,
    emailAlerts: true,
    darkMode: false,
    autoRefresh: true,
    currency: 'USD',
    language: 'English'
  });

  const notifications = [
    {
      id: 1,
      type: 'payment',
      title: 'Payment Received',
      message: 'You received $299.99 from Arjun Sharma',
      time: '2 min ago',
      icon: 'ri-money-dollar-circle-fill',
      color: 'text-green-600',
      bgColor: 'bg-green-100',
      read: false
    },
    {
      id: 2,
      type: 'alert',
      title: 'Failed Payment Alert',
      message: 'Payment of $89.50 failed for Rajesh Kumar',
      time: '12 min ago',
      icon: 'ri-error-warning-fill',
      color: 'text-red-600',
      bgColor: 'bg-red-100',
      read: false
    },
    {
      id: 3,
      type: 'user',
      title: 'New User Registered',
      message: 'Sneha Gupta has joined your platform',
      time: '1 hour ago',
      icon: 'ri-user-add-fill',
      color: 'text-blue-600',
      bgColor: 'bg-blue-100',
      read: true
    },
    {
      id: 4,
      type: 'system',
      title: 'System Update',
      message: 'Payment gateway maintenance scheduled for tonight',
      time: '3 hours ago',
      icon: 'ri-settings-fill',
      color: 'text-purple-600',
      bgColor: 'bg-purple-100',
      read: true
    },
    {
      id: 5,
      type: 'payment',
      title: 'Large Transaction',
      message: 'Payment of $450.00 processed successfully',
      time: '5 hours ago',
      icon: 'ri-money-dollar-circle-fill',
      color: 'text-green-600',
      bgColor: 'bg-green-100',
      read: true
    },
    {
      id: 6,
      type: 'alert',
      title: 'Security Alert',
      message: 'Multiple login attempts detected',
      time: '1 day ago',
      icon: 'ri-shield-check-fill',
      color: 'text-orange-600',
      bgColor: 'bg-orange-100',
      read: true
    }
  ];

  const dashboardStats = [
    { title: 'Total Revenue', value: '$45,320', change: '+12.5%', icon: 'ri-money-dollar-circle-line', color: 'bg-green-500' },
    { title: 'Transactions Today', value: '1,234', change: '+5.2%', icon: 'ri-exchange-line', color: 'bg-blue-500' },
    { title: 'Failed Payments', value: '23', change: '-2.1%', icon: 'ri-error-warning-line', color: 'bg-red-500' },
    { title: 'Active Users', value: '5,678', change: '+8.7%', icon: 'ri-user-line', color: 'bg-purple-500' }
  ];

  const recentTransactions = [
    { id: '1', user: 'Arjun Sharma', amount: '$299.99', status: 'success', method: 'Credit Card', time: '2 min ago', receiver: 'Arjun Sharma' },
    { id: '2', user: 'Priya Patel', amount: '$150.00', status: 'pending', method: 'PayPal', time: '5 min ago', receiver: 'Priya Patel' },
    { id: '3', user: 'Rajesh Kumar', amount: '$89.50', status: 'failed', method: 'Bank Transfer', time: '12 min ago', receiver: 'Rajesh Kumar' },
    { id: '4', user: 'Sneha Gupta', amount: '$450.00', status: 'success', method: 'Credit Card', time: '18 min ago', receiver: 'Sneha Gupta' },
    { id: '5', user: 'Vikram Singh', amount: '$75.25', status: 'success', method: 'PayPal', time: '25 min ago', receiver: 'Vikram Singh' }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'success': return 'bg-green-100 text-green-800';
      case 'pending': return 'bg-yellow-100 text-yellow-800';
      case 'failed': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const handleSettingChange = (key: string, value: boolean | string) => {
    setSettings(prev => ({
      ...prev,
      [key]: value
    }));
  };

  const markAsRead = (id: number) => {
    // In a real app, this would update the notification status
    console.log('Mark notification as read:', id);
  };

  const markAllAsRead = () => {
    // In a real app, this would mark all notifications as read
    console.log('Mark all notifications as read');
  };

  const unreadCount = notifications.filter(n => !n.read).length;

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="fixed top-0 w-full bg-white shadow-sm z-50 animate-slide-down">
        <div className="px-4 py-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center animate-pulse-slow">
                <span className="text-blue-600 font-bold text-lg" style={{fontFamily: '"Pacifico", serif'}}>P</span>
              </div>
              <div>
                <h1 className="text-lg font-bold text-gray-800 animate-fade-in">Payment Dashboard</h1>
                <p className="text-xs text-gray-500 animate-fade-in-delay">Welcome back, Admin</p>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <button 
                onClick={() => setShowNotifications(true)}
                className="relative w-8 h-8 flex items-center justify-center hover:bg-gray-100 rounded-full transition-all duration-200 transform hover:scale-110 animate-bounce-subtle"
              >
                <i className="ri-notification-line text-gray-600 text-xl"></i>
                {unreadCount > 0 && (
                  <span className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 text-white text-xs rounded-full flex items-center justify-center animate-pulse">
                    {unreadCount}
                  </span>
                )}
              </button>
              <button 
                onClick={() => setShowSettings(true)}
                className="w-8 h-8 flex items-center justify-center hover:bg-gray-100 rounded-full transition-all duration-200 transform hover:scale-110 animate-bounce-subtle"
              >
                <i className="ri-settings-line text-gray-600 text-xl"></i>
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Notifications Modal */}
      {showNotifications && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4 animate-fade-in">
          <div className="bg-white rounded-xl shadow-xl max-w-md w-full max-h-[80vh] overflow-hidden animate-slide-in-up">
            {/* Modal Header */}
            <div className="flex items-center justify-between p-4 border-b border-gray-200">
              <div className="flex items-center space-x-2">
                <h2 className="text-xl font-semibold text-gray-800">Notifications</h2>
                {unreadCount > 0 && (
                  <span className="bg-red-500 text-white text-xs px-2 py-1 rounded-full">
                    {unreadCount}
                  </span>
                )}
              </div>
              <div className="flex items-center space-x-2">
                {unreadCount > 0 && (
                  <button 
                    onClick={markAllAsRead}
                    className="text-sm text-blue-600 hover:text-blue-700 transition-colors"
                  >
                    Mark all read
                  </button>
                )}
                <button 
                  onClick={() => setShowNotifications(false)}
                  className="w-8 h-8 flex items-center justify-center hover:bg-gray-100 rounded-full transition-all duration-200 transform hover:scale-110"
                >
                  <i className="ri-close-line text-gray-600 text-xl"></i>
                </button>
              </div>
            </div>

            {/* Modal Content */}
            <div className="max-h-[60vh] overflow-y-auto">
              <div className="divide-y divide-gray-100">
                {notifications.map((notification, index) => (
                  <div 
                    key={notification.id}
                    className={`p-4 hover:bg-gray-50 transition-colors cursor-pointer animate-slide-in-left ${
                      !notification.read ? 'bg-blue-50/50' : ''
                    }`}
                    style={{animationDelay: `${index * 0.1}s`}}
                    onClick={() => markAsRead(notification.id)}
                  >
                    <div className="flex items-start space-x-3">
                      <div className={`w-10 h-10 rounded-full flex items-center justify-center ${notification.bgColor} flex-shrink-0`}>
                        <i className={`${notification.icon} ${notification.color} text-lg`}></i>
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between">
                          <p className={`font-medium text-gray-800 ${!notification.read ? 'text-blue-900' : ''}`}>
                            {notification.title}
                          </p>
                          {!notification.read && (
                            <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                          )}
                        </div>
                        <p className="text-sm text-gray-600 mt-1">{notification.message}</p>
                        <p className="text-xs text-gray-400 mt-2">{notification.time}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Modal Footer */}
            <div className="p-4 border-t border-gray-200 bg-gray-50">
              <div className="flex items-center justify-between">
                <Link 
                  href="/notifications" 
                  className="text-blue-600 hover:text-blue-700 font-medium text-sm transition-colors"
                >
                  View all notifications
                </Link>
                <div className="flex items-center space-x-2">
                  <button className="p-2 hover:bg-gray-200 rounded-full transition-colors">
                    <i className="ri-settings-line text-gray-600 text-sm"></i>
                  </button>
                  <button className="p-2 hover:bg-gray-200 rounded-full transition-colors">
                    <i className="ri-filter-line text-gray-600 text-sm"></i>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Settings Modal */}
      {showSettings && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4 animate-fade-in">
          <div className="bg-white rounded-xl shadow-xl max-w-md w-full max-h-[80vh] overflow-y-auto animate-scale-up">
            {/* Modal Header */}
            <div className="flex items-center justify-between p-4 border-b border-gray-200">
              <h2 className="text-xl font-semibold text-gray-800">Settings</h2>
              <button 
                onClick={() => setShowSettings(false)}
                className="w-8 h-8 flex items-center justify-center hover:bg-gray-100 rounded-full transition-all duration-200 transform hover:scale-110"
              >
                <i className="ri-close-line text-gray-600 text-xl"></i>
              </button>
            </div>

            {/* Modal Content */}
            <div className="p-4 space-y-6">
              {/* Notifications Section */}
              <div>
                <h3 className="font-medium text-gray-800 mb-3">Notifications</h3>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                        <i className="ri-notification-line text-blue-600 text-sm"></i>
                      </div>
                      <div>
                        <p className="font-medium text-gray-800 text-sm">Push Notifications</p>
                        <p className="text-xs text-gray-500">Receive alerts for new transactions</p>
                      </div>
                    </div>
                    <button
                      onClick={() => handleSettingChange('notifications', !settings.notifications)}
                      className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                        settings.notifications ? 'bg-blue-600' : 'bg-gray-200'
                      }`}
                    >
                      <span
                        className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                          settings.notifications ? 'translate-x-6' : 'translate-x-1'
                        }`}
                      />
                    </button>
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
                        <i className="ri-mail-line text-green-600 text-sm"></i>
                      </div>
                      <div>
                        <p className="font-medium text-gray-800 text-sm">Email Alerts</p>
                        <p className="text-xs text-gray-500">Get daily summary emails</p>
                      </div>
                    </div>
                    <button
                      onClick={() => handleSettingChange('emailAlerts', !settings.emailAlerts)}
                      className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                        settings.emailAlerts ? 'bg-blue-600' : 'bg-gray-200'
                      }`}
                    >
                      <span
                        className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                          settings.emailAlerts ? 'translate-x-6' : 'translate-x-1'
                        }`}
                      />
                    </button>
                  </div>
                </div>
              </div>

              {/* Appearance Section */}
              <div>
                <h3 className="font-medium text-gray-800 mb-3">Appearance</h3>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <div className="w-8 h-8 bg-purple-100 rounded-full flex items-center justify-center">
                        <i className="ri-moon-line text-purple-600 text-sm"></i>
                      </div>
                      <div>
                        <p className="font-medium text-gray-800 text-sm">Dark Mode</p>
                        <p className="text-xs text-gray-500">Switch to dark theme</p>
                      </div>
                    </div>
                    <button
                      onClick={() => handleSettingChange('darkMode', !settings.darkMode)}
                      className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                        settings.darkMode ? 'bg-blue-600' : 'bg-gray-200'
                      }`}
                    >
                      <span
                        className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                          settings.darkMode ? 'translate-x-6' : 'translate-x-1'
                        }`}
                      />
                    </button>
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <div className="w-8 h-8 bg-orange-100 rounded-full flex items-center justify-center">
                        <i className="ri-refresh-line text-orange-600 text-sm"></i>
                      </div>
                      <div>
                        <p className="font-medium text-gray-800 text-sm">Auto Refresh</p>
                        <p className="text-xs text-gray-500">Automatically update data</p>
                      </div>
                    </div>
                    <button
                      onClick={() => handleSettingChange('autoRefresh', !settings.autoRefresh)}
                      className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                        settings.autoRefresh ? 'bg-blue-600' : 'bg-gray-200'
                      }`}
                    >
                      <span
                        className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                          settings.autoRefresh ? 'translate-x-6' : 'translate-x-1'
                        }`}
                      />
                    </button>
                  </div>
                </div>
              </div>

              {/* Preferences Section */}
              <div>
                <h3 className="font-medium text-gray-800 mb-3">Preferences</h3>
                <div className="space-y-3">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Currency</label>
                    <select
                      value={settings.currency}
                      onChange={(e) => handleSettingChange('currency', e.target.value)}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    >
                      <option value="USD">USD - US Dollar</option>
                      <option value="EUR">EUR - Euro</option>
                      <option value="GBP">GBP - British Pound</option>
                      <option value="INR">INR - Indian Rupee</option>
                      <option value="JPY">JPY - Japanese Yen</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Language</label>
                    <select
                      value={settings.language}
                      onChange={(e) => handleSettingChange('language', e.target.value)}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    >
                      <option value="English">English</option>
                      <option value="Spanish">Spanish</option>
                      <option value="French">French</option>
                      <option value="German">German</option>
                      <option value="Hindi">Hindi</option>
                    </select>
                  </div>
                </div>
              </div>

              {/* Account Section */}
              <div>
                <h3 className="font-medium text-gray-800 mb-3">Account</h3>
                <div className="space-y-2">
                  <button className="w-full flex items-center justify-between p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
                    <div className="flex items-center space-x-3">
                      <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                        <i className="ri-user-line text-blue-600 text-sm"></i>
                      </div>
                      <span className="font-medium text-gray-800 text-sm">Profile Settings</span>
                    </div>
                    <i className="ri-arrow-right-s-line text-gray-400"></i>
                  </button>

                  <button className="w-full flex items-center justify-between p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
                    <div className="flex items-center space-x-3">
                      <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
                        <i className="ri-shield-line text-green-600 text-sm"></i>
                      </div>
                      <span className="font-medium text-gray-800 text-sm">Security</span>
                    </div>
                    <i className="ri-arrow-right-s-line text-gray-400"></i>
                  </button>

                  <button className="w-full flex items-center justify-between p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
                    <div className="flex items-center space-x-3">
                      <div className="w-8 h-8 bg-yellow-100 rounded-full flex items-center justify-center">
                        <i className="ri-help-line text-yellow-600 text-sm"></i>
                      </div>
                      <span className="font-medium text-gray-800 text-sm">Help & Support</span>
                    </div>
                    <i className="ri-arrow-right-s-line text-gray-400"></i>
                  </button>
                </div>
              </div>
            </div>

            {/* Modal Footer */}
            <div className="flex items-center justify-between p-4 border-t border-gray-200">
              <Link href="/login" className="text-red-600 hover:text-red-700 font-medium text-sm transition-colors">
                Sign Out
              </Link>
              <button 
                onClick={() => setShowSettings(false)}
                className="bg-blue-500 text-white px-4 py-2 rounded-lg font-medium hover:bg-blue-600 transition-colors !rounded-button"
              >
                Done
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Main Content */}
      <main className="pt-20 pb-20">
        {/* Stats Overview */}
        <div className="px-4 py-6">
          <div className="grid grid-cols-2 gap-4 mb-6">
            <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-4 animate-fade-in-up transform hover:scale-[1.02] transition-all duration-300" style={{animationDelay: '0.1s'}}>
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Today's Revenue</p>
                  <h3 className="text-xl font-bold text-gray-800 mt-1 animate-number-count">$12,450</h3>
                </div>
                <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center animate-pulse-slow">
                  <i className="ri-money-dollar-circle-line text-green-600 text-xl"></i>
                </div>
              </div>
            </div>
            <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-4 animate-fade-in-up transform hover:scale-[1.02] transition-all duration-300" style={{animationDelay: '0.2s'}}>
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Transactions</p>
                  <h3 className="text-xl font-bold text-gray-800 mt-1 animate-number-count">2,394</h3>
                </div>
                <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center animate-pulse-slow">
                  <i className="ri-exchange-line text-blue-600 text-xl"></i>
                </div>
              </div>
            </div>
            <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-4 animate-fade-in-up transform hover:scale-[1.02] transition-all duration-300" style={{animationDelay: '0.3s'}}>
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Active Users</p>
                  <h3 className="text-xl font-bold text-gray-800 mt-1 animate-number-count">1,847</h3>
                </div>
                <div className="w-10 h-10 bg-purple-100 rounded-full flex items-center justify-center animate-pulse-slow">
                  <i className="ri-user-line text-purple-600 text-xl"></i>
                </div>
              </div>
            </div>
            <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-4 animate-fade-in-up transform hover:scale-[1.02] transition-all duration-300" style={{animationDelay: '0.4s'}}>
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Failed Payments</p>
                  <h3 className="text-xl font-bold text-red-600 mt-1 animate-number-count">23</h3>
                </div>
                <div className="w-10 h-10 bg-red-100 rounded-full flex items-center justify-center animate-pulse-slow">
                  <i className="ri-error-warning-line text-red-600 text-xl"></i>
                </div>
              </div>
            </div>
          </div>

          {/* Quick Actions */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 mb-6 animate-fade-in-up" style={{animationDelay: '0.5s'}}>
            <div className="p-4 border-b border-gray-100">
              <h3 className="font-semibold text-gray-800">Quick Actions</h3>
            </div>
            <div className="p-4">
              <div className="grid grid-cols-2 gap-3">
                <Link href="/add-payment" className="flex items-center space-x-3 p-3 bg-blue-50 rounded-lg hover:bg-blue-100 transition-all duration-200 transform hover:scale-[1.02] animate-slide-in-left" style={{animationDelay: '0.6s'}}>
                  <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center">
                    <i className="ri-add-line text-white text-lg"></i>
                  </div>
                  <span className="text-sm font-medium text-blue-700">Add Payment</span>
                </Link>
                <Link href="/add-user" className="flex items-center space-x-3 p-3 bg-green-50 rounded-lg hover:bg-green-100 transition-all duration-200 transform hover:scale-[1.02] animate-slide-in-right" style={{animationDelay: '0.6s'}}>
                  <div className="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center">
                    <i className="ri-user-add-line text-white text-lg"></i>
                  </div>
                  <span className="text-sm font-medium text-green-700">Add User</span>
                </Link>
              </div>
            </div>
          </div>

          {/* Revenue Chart */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 mb-6 animate-fade-in-up" style={{animationDelay: '0.7s'}}>
            <div className="p-4 border-b border-gray-100">
              <h3 className="font-semibold text-gray-800">Revenue Trend</h3>
            </div>
            <div className="p-4">
              <div className="h-48 bg-gradient-to-br from-blue-50 to-purple-50 rounded-lg flex items-center justify-center animate-pulse-slow">
                <img 
                  src="https://readdy.ai/api/search-image?query=Beautiful%20modern%20revenue%20chart%20with%20ascending%20line%20graph%2C%20clean%20dashboard%20analytics%2C%20blue%20and%20purple%20gradient%20colors%2C%20professional%20financial%20data%20visualization%2C%20smooth%20curves%2C%20grid%20background%2C%20minimalist%20design%2C%20high%20quality&width=300&height=180&seq=dashboard_chart&orientation=landscape"
                  alt="Revenue Chart"
                  className="w-full h-full object-cover rounded-lg"
                />
              </div>
            </div>
          </div>

          {/* Recent Transactions */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 animate-fade-in-up" style={{animationDelay: '0.8s'}}>
            <div className="p-4 border-b border-gray-100">
              <div className="flex items-center justify-between">
                <h3 className="font-semibold text-gray-800">Recent Transactions</h3>
                <Link href="/transactions" className="text-sm text-blue-600 hover:text-blue-700 transition-colors duration-200">View All</Link>
              </div>
            </div>
            <div className="p-4">
              <div className="space-y-3">
                {recentTransactions.map((transaction, index) => (
                  <div key={transaction.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-all duration-200 transform hover:scale-[1.02] animate-slide-in-left" style={{animationDelay: `${0.9 + index * 0.1}s`}}>
                    <div className="flex items-center space-x-3">
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center animate-pulse-slow 
                        ${transaction.status === 'success' ? 'bg-green-100' : 
                        transaction.status === 'pending' ? 'bg-yellow-100' : 'bg-red-100'
                      }`}>
                        <i className={`text-sm 
                          ${transaction.status === 'success' ? 'ri-check-line text-green-600' : 
                          transaction.status === 'pending' ? 'ri-time-line text-yellow-600' : 'ri-close-line text-red-600'
                        }`}></i>
                      </div>
                      <div>
                        <p className="font-medium text-gray-800 text-sm">{transaction.receiver}</p>
                        <p className="text-xs text-gray-500">{transaction.method} • {transaction.time}</p>
                      </div>
                    </div>
                    <span className="font-semibold text-gray-800">{transaction.amount}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* Bottom Navigation */}
      <nav className="fixed bottom-0 w-full bg-white border-t border-gray-200 z-50 animate-slide-up">
        <div className="grid grid-cols-4 py-2">
          <Link href="/" className="flex flex-col items-center py-2 text-blue-600 transition-all duration-200 transform hover:scale-110">
            <div className="w-6 h-6 flex items-center justify-center mb-1">
              <i className="ri-dashboard-fill text-xl"></i>
            </div>
            <span className="text-xs">Dashboard</span>
          </Link>
          <Link href="/transactions" className="flex flex-col items-center py-2 text-gray-400 hover:text-blue-500 transition-all duration-200 transform hover:scale-110">
            <div className="w-6 h-6 flex items-center justify-center mb-1">
              <i className="ri-exchange-line text-xl"></i>
            </div>
            <span className="text-xs">Transactions</span>
          </Link>
          <Link href="/users" className="flex flex-col items-center py-2 text-gray-400 hover:text-blue-500 transition-all duration-200 transform hover:scale-110">
            <div className="w-6 h-6 flex items-center justify-center mb-1">
              <i className="ri-user-line text-xl"></i>
            </div>
            <span className="text-xs">Users</span>
          </Link>
          <Link href="/reports" className="flex flex-col items-center py-2 text-gray-400 hover:text-blue-500 transition-all duration-200 transform hover:scale-110">
            <div className="w-6 h-6 flex items-center justify-center mb-1">
              <i className="ri-bar-chart-line text-xl"></i>
            </div>
            <span className="text-xs">Reports</span>
          </Link>
        </div>
      </nav>

      <style jsx>{`
        @keyframes slide-down {
          from {
            transform: translateY(-100%);
            opacity: 0;
          }
          to {
            transform: translateY(0);
            opacity: 1;
          }
        }

        @keyframes slide-up {
          from {
            transform: translateY(100%);
            opacity: 0;
          }
          to {
            transform: translateY(0);
            opacity: 1;
          }
        }

        @keyframes slide-in-up {
          from {
            transform: translateY(100%);
            opacity: 0;
          }
          to {
            transform: translateY(0);
            opacity: 1;
          }
        }

        @keyframes fade-in {
          from {
            opacity: 0;
          }
          to {
            opacity: 1;
          }
        }

        @keyframes fade-in-up {
          from {
            opacity: 0;
            transform: translateY(30px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }

        @keyframes slide-in-left {
          from {
            opacity: 0;
            transform: translateX(-30px);
          }
          to {
            opacity: 1;
            transform: translateX(0);
          }
        }

        @keyframes slide-in-right {
          from {
            opacity: 0;
            transform: translateX(30px);
          }
          to {
            opacity: 1;
            transform: translateX(0);
          }
        }

        @keyframes bounce-subtle {
          0%, 100% {
            transform: translateY(0);
          }
          50% {
            transform: translateY(-2px);
          }
        }

        @keyframes number-count {
          from {
            opacity: 0;
            transform: scale(0.8);
          }
          to {
            opacity: 1;
            transform: scale(1);
          }
        }

        @keyframes scale-up {
          from {
            opacity: 0;
            transform: scale(0.95);
          }
          to {
            opacity: 1;
            transform: scale(1);
          }
        }

        .animate-slide-down {
          animation: slide-down 0.6s ease-out;
        }

        .animate-slide-up {
          animation: slide-up 0.6s ease-out;
        }

        .animate-slide-in-up {
          animation: slide-in-up 0.3s ease-out;
        }

        .animate-fade-in {
          animation: fade-in 0.8s ease-out;
        }

        .animate-fade-in-delay {
          animation: fade-in 0.8s ease-out 0.2s both;
        }

        .animate-fade-in-up {
          animation: fade-in-up 0.8s ease-out both;
        }

        .animate-slide-in-left {
          animation: slide-in-left 0.6s ease-out both;
        }

        .animate-slide-in-right {
          animation: slide-in-right 0.6s ease-out both;
        }

        .animate-bounce-subtle {
          animation: bounce-subtle 2s ease-in-out infinite;
        }

        .animate-number-count {
          animation: number-count 1s ease-out 0.5s both;
        }

        .animate-scale-up {
          animation: scale-up 0.3s ease-out;
        }

        .animate-pulse-slow {
          animation: pulse 3s ease-in-out infinite;
        }

        @keyframes pulse {
          0%, 100% {
            transform: scale(1);
            opacity: 1;
          }
          50% {
            transform: scale(1.05);
            opacity: 0.9;
          }
        }
      `}</style>
    </div>
  );
}