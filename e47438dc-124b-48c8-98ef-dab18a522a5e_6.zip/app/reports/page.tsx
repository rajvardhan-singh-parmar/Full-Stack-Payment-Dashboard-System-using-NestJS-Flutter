
'use client';

import Link from 'next/link';
import { useState } from 'react';

export default function ReportsPage() {
  const [selectedTab, setSelectedTab] = useState('reports');
  const [selectedPeriod, setSelectedPeriod] = useState('7days');

  const revenueData = {
    '7days': { current: '$12,450', previous: '$10,320', change: '+20.6%' },
    '30days': { current: '$45,320', previous: '$38,210', change: '+18.6%' },
    '90days': { current: '$128,450', previous: '$105,320', change: '+21.9%' }
  };

  const failedTransactionsData = {
    '7days': { current: '23', previous: '31', change: '-25.8%' },
    '30days': { current: '89', previous: '102', change: '-12.7%' },
    '90days': { current: '234', previous: '298', change: '-21.5%' }
  };

  const topPaymentMethods = [
    { method: 'Credit Card', amount: '$28,450', percentage: '62.8%', color: 'bg-blue-500' },
    { method: 'PayPal', amount: '$12,320', percentage: '27.2%', color: 'bg-yellow-500' },
    { method: 'Bank Transfer', amount: '$3,890', percentage: '8.6%', color: 'bg-green-500' },
    { method: 'Digital Wallet', amount: '$660', percentage: '1.4%', color: 'bg-purple-500' }
  ];

  const recentActivity = [
    { type: 'revenue', message: 'Revenue increased by 12.5%', time: '2 hours ago', icon: 'ri-trending-up-line', color: 'text-green-600' },
    { type: 'failed', message: 'Failed transactions decreased by 8%', time: '5 hours ago', icon: 'ri-trending-down-line', color: 'text-red-600' },
    { type: 'user', message: 'New user registered', time: '1 day ago', icon: 'ri-user-add-line', color: 'text-blue-600' },
    { type: 'payment', message: 'Payment method added', time: '2 days ago', icon: 'ri-bank-card-line', color: 'text-purple-600' }
  ];

  const getCurrentData = () => revenueData[selectedPeriod as keyof typeof revenueData];
  const getCurrentFailedData = () => failedTransactionsData[selectedPeriod as keyof typeof failedTransactionsData];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="fixed top-0 w-full bg-white shadow-sm z-50">
        <div className="px-4 py-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Link href="/" className="w-8 h-8 flex items-center justify-center">
                <i className="ri-arrow-left-line text-gray-600 text-xl"></i>
              </Link>
              <h1 className="text-xl font-bold text-gray-800">Reports</h1>
            </div>
            <div className="flex items-center space-x-4">
              <button className="w-8 h-8 flex items-center justify-center">
                <i className="ri-download-line text-gray-600 text-xl"></i>
              </button>
              <button className="w-8 h-8 flex items-center justify-center">
                <i className="ri-share-line text-gray-600 text-xl"></i>
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="pt-16 pb-20">
        {/* Period Filter */}
        <div className="px-4 py-4 bg-white border-b border-gray-200">
          <div className="flex space-x-1 bg-gray-100 rounded-lg p-1">
            <button
              onClick={() => setSelectedPeriod('7days')}
              className={`px-4 py-2 rounded-md text-sm font-medium transition-colors \${selectedPeriod === '7days' ? 'bg-white text-blue-600 shadow-sm' : 'text-gray-600'}`}
            >
              7 Days
            </button>
            <button
              onClick={() => setSelectedPeriod('30days')}
              className={`px-4 py-2 rounded-md text-sm font-medium transition-colors \${selectedPeriod === '30days' ? 'bg-white text-blue-600 shadow-sm' : 'text-gray-600'}`}
            >
              30 Days
            </button>
            <button
              onClick={() => setSelectedPeriod('90days')}
              className={`px-4 py-2 rounded-md text-sm font-medium transition-colors \${selectedPeriod === '90days' ? 'bg-white text-blue-600 shadow-sm' : 'text-gray-600'}`}
            >
              90 Days
            </button>
          </div>
        </div>

        <div className="px-4 py-6">
          {/* Revenue Trend */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 mb-6">
            <div className="p-4 border-b border-gray-100">
              <h3 className="font-semibold text-gray-800">Revenue Trend</h3>
            </div>
            <div className="p-4">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <p className="text-3xl font-bold text-gray-800">{getCurrentData().current}</p>
                  <p className="text-sm text-gray-600">Total Revenue</p>
                </div>
                <div className="text-right">
                  <span className="text-lg font-semibold text-green-600">{getCurrentData().change}</span>
                  <p className="text-sm text-gray-600">vs previous period</p>
                </div>
              </div>
              <div className="h-48 bg-gray-50 rounded-lg flex items-center justify-center">
                <img 
                  src="https://readdy.ai/api/search-image?query=Beautiful%20revenue%20growth%20chart%2C%20upward%20trending%20line%20graph%20with%20blue%20and%20green%20gradient%20colors%2C%20financial%20dashboard%20analytics%2C%20clean%20modern%20design%2C%20professional%20business%20metrics%20visualization%2C%20smooth%20curved%20lines%20showing%20positive%20growth%2C%20minimalist%20chart%20background&width=300&height=200&seq=revenuechart002&orientation=landscape"
                  alt="Revenue Trend Chart"
                  className="w-full h-full object-cover rounded-lg"
                />
              </div>
            </div>
          </div>

          {/* Failed Transactions */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 mb-6">
            <div className="p-4 border-b border-gray-100">
              <h3 className="font-semibold text-gray-800">Failed Transactions</h3>
            </div>
            <div className="p-4">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <p className="text-3xl font-bold text-red-600">{getCurrentFailedData().current}</p>
                  <p className="text-sm text-gray-600">Failed Payments</p>
                </div>
                <div className="text-right">
                  <span className="text-lg font-semibold text-green-600">{getCurrentFailedData().change}</span>
                  <p className="text-sm text-gray-600">vs previous period</p>
                </div>
              </div>
              <div className="h-32 bg-gray-50 rounded-lg flex items-center justify-center">
                <img 
                  src="https://readdy.ai/api/search-image?query=Failed%20transactions%20analytics%20chart%2C%20declining%20red%20line%20graph%20showing%20improvement%2C%20error%20rate%20visualization%2C%20dashboard%20metrics%20with%20red%20and%20orange%20colors%2C%20professional%20business%20chart%2C%20downward%20trend%20indicating%20better%20performance%2C%20clean%20minimalist%20design&width=300&height=130&seq=failedchart001&orientation=landscape"
                  alt="Failed Transactions Chart"
                  className="w-full h-full object-cover rounded-lg"
                />
              </div>
            </div>
          </div>

          {/* Payment Methods */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 mb-6">
            <div className="p-4 border-b border-gray-100">
              <h3 className="font-semibold text-gray-800">Payment Methods</h3>
            </div>
            <div className="p-4">
              <div className="space-y-4">
                {topPaymentMethods.map((method, index) => (
                  <div key={index} className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <div className={`w-4 h-4 rounded-full \${method.color}`}></div>
                      <span className="font-medium text-gray-800 text-sm">{method.method}</span>
                    </div>
                    <div className="text-right">
                      <p className="font-semibold text-gray-800 text-sm">{method.amount}</p>
                      <p className="text-xs text-gray-600">{method.percentage}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Activity Feed */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-100">
            <div className="p-4 border-b border-gray-100">
              <h3 className="font-semibold text-gray-800">Recent Activity</h3>
            </div>
            <div className="p-4">
              <div className="space-y-4">
                {recentActivity.map((activity, index) => (
                  <div key={index} className="flex items-start space-x-3">
                    <div className="w-8 h-8 bg-gray-100 rounded-full flex items-center justify-center">
                      <i className={`\${activity.icon} \${activity.color} text-sm`}></i>
                    </div>
                    <div className="flex-1">
                      <p className="text-sm text-gray-800">{activity.message}</p>
                      <p className="text-xs text-gray-500 mt-1">{activity.time}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* Bottom Navigation */}
      <nav className="fixed bottom-0 w-full bg-white border-t border-gray-200 z-50">
        <div className="grid grid-cols-4 py-2">
          <Link href="/" className="flex flex-col items-center py-2 text-gray-400">
            <div className="w-6 h-6 flex items-center justify-center mb-1">
              <i className="ri-dashboard-line text-xl"></i>
            </div>
            <span className="text-xs">Dashboard</span>
          </Link>
          <Link href="/transactions" className="flex flex-col items-center py-2 text-gray-400">
            <div className="w-6 h-6 flex items-center justify-center mb-1">
              <i className="ri-exchange-line text-xl"></i>
            </div>
            <span className="text-xs">Transactions</span>
          </Link>
          <Link href="/users" className="flex flex-col items-center py-2 text-gray-400">
            <div className="w-6 h-6 flex items-center justify-center mb-1">
              <i className="ri-user-line text-xl"></i>
            </div>
            <span className="text-xs">Users</span>
          </Link>
          <button
            onClick={() => setSelectedTab('reports')}
            className={`flex flex-col items-center py-2 \${selectedTab === 'reports' ? 'text-blue-600' : 'text-gray-400'}`}
          >
            <div className="w-6 h-6 flex items-center justify-center mb-1">
              <i className="ri-bar-chart-line text-xl"></i>
            </div>
            <span className="text-xs">Reports</span>
          </button>
        </div>
      </nav>
    </div>
  );
}
