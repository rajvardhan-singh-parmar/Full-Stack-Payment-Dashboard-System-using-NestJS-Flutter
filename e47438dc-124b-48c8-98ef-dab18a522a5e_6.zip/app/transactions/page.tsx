
'use client';

import Link from 'next/link';
import { useState } from 'react';

export default function TransactionsPage() {
  const [selectedTab, setSelectedTab] = useState('transactions');
  const [selectedStatus, setSelectedStatus] = useState('all');
  const [selectedMethod, setSelectedMethod] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [showFilters, setShowFilters] = useState(false);
  const [statusFilter, setStatusFilter] = useState('all');
  const [methodFilter, setMethodFilter] = useState('all');

  const transactions = [
    { id: 'TXN001', user: 'Arjun Sharma', amount: '$299.99', status: 'success', method: 'Credit Card', date: '2024-01-15', time: '10:30 AM', receiver: 'Arjun Sharma' },
    { id: 'TXN002', user: 'Priya Patel', amount: '$150.00', status: 'pending', method: 'PayPal', date: '2024-01-15', time: '09:45 AM', receiver: 'Priya Patel' },
    { id: 'TXN003', user: 'Rajesh Kumar', amount: '$89.50', status: 'failed', method: 'Bank Transfer', date: '2024-01-15', time: '08:20 AM', receiver: 'Rajesh Kumar' },
    { id: 'TXN004', user: 'Sneha Gupta', amount: '$450.00', status: 'success', method: 'Credit Card', date: '2024-01-14', time: '11:15 PM', receiver: 'Sneha Gupta' },
    { id: 'TXN005', user: 'Vikram Singh', amount: '$75.25', status: 'success', method: 'PayPal', date: '2024-01-14', time: '10:30 PM', receiver: 'Vikram Singh' },
    { id: 'TXN006', user: 'Anita Desai', amount: '$320.00', status: 'pending', method: 'Bank Transfer', date: '2024-01-14', time: '09:45 PM', receiver: 'Anita Desai' },
    { id: 'TXN007', user: 'Rohit Verma', amount: '$125.75', status: 'failed', method: 'Credit Card', date: '2024-01-14', time: '08:20 PM', receiver: 'Rohit Verma' },
    { id: 'TXN008', user: 'Kavya Nair', amount: '$199.99', status: 'success', method: 'PayPal', date: '2024-01-13', time: '07:30 PM', receiver: 'Kavya Nair' },
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'success': return 'bg-green-100 text-green-800';
      case 'pending': return 'bg-yellow-100 text-yellow-800';
      case 'failed': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const filteredTransactions = transactions.filter(transaction => {
    const matchesStatus = statusFilter === 'all' || transaction.status === statusFilter;
    const matchesMethod = methodFilter === 'all' || transaction.method === methodFilter;
    const matchesSearch = searchQuery === '' || 
      transaction.user.toLowerCase().includes(searchQuery.toLowerCase()) ||
      transaction.id.toLowerCase().includes(searchQuery.toLowerCase());

    return matchesStatus && matchesMethod && matchesSearch;
  });

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="fixed top-0 w-full bg-white shadow-sm z-50 animate-slide-down">
        <div className="px-4 py-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Link href="/" className="w-8 h-8 flex items-center justify-center hover:bg-gray-100 rounded-full transition-all duration-200 transform hover:scale-110">
                <i className="ri-arrow-left-line text-gray-600 text-xl"></i>
              </Link>
              <h1 className="text-xl font-bold text-gray-800">Transactions</h1>
            </div>
            <button className="w-8 h-8 flex items-center justify-center hover:bg-gray-100 rounded-full transition-all duration-200 transform hover:scale-110">
              <i className="ri-filter-line text-gray-600 text-xl"></i>
            </button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="pt-16 pb-20">
        {/* Search & Filter */}
        <div className="px-4 py-4 animate-fade-in-up">
          <div className="flex space-x-3 mb-4">
            <div className="flex-1 relative">
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-300 transform hover:scale-[1.02] focus:scale-[1.02]"
                placeholder="Search transactions..."
              />
              <div className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 flex items-center justify-center">
                <i className="ri-search-line text-gray-400"></i>
              </div>
            </div>
            <button 
              onClick={() => setShowFilters(!showFilters)}
              className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-all duration-200 transform hover:scale-[1.02] !rounded-button"
            >
              <i className="ri-filter-line text-gray-600"></i>
            </button>
          </div>

          {/* Filters */}
          {showFilters && (
            <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-4 mb-4 animate-fade-in-up">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Status</label>
                  <select
                    value={statusFilter}
                    onChange={(e) => setStatusFilter(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-300"
                  >
                    <option value="all">All Status</option>
                    <option value="success">Success</option>
                    <option value="pending">Pending</option>
                    <option value="failed">Failed</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Method</label>
                  <select
                    value={methodFilter}
                    onChange={(e) => setMethodFilter(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-300"
                  >
                    <option value="all">All Methods</option>
                    <option value="Credit Card">Credit Card</option>
                    <option value="PayPal">PayPal</option>
                    <option value="Bank Transfer">Bank Transfer</option>
                    <option value="Digital Wallet">Digital Wallet</option>
                  </select>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Stats */}
        <div className="px-4 mb-4">
          <div className="grid grid-cols-3 gap-3">
            <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-3 text-center animate-fade-in-up transform hover:scale-[1.02] transition-all duration-300" style={{animationDelay: '0.1s'}}>
              <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-2 animate-pulse-slow">
                <i className="ri-check-line text-green-600 text-sm"></i>
              </div>
              <p className="text-lg font-bold text-gray-800 animate-number-count">2,847</p>
              <p className="text-xs text-gray-500">Success</p>
            </div>
            <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-3 text-center animate-fade-in-up transform hover:scale-[1.02] transition-all duration-300" style={{animationDelay: '0.2s'}}>
              <div className="w-8 h-8 bg-yellow-100 rounded-full flex items-center justify-center mx-auto mb-2 animate-pulse-slow">
                <i className="ri-time-line text-yellow-600 text-sm"></i>
              </div>
              <p className="text-lg font-bold text-gray-800 animate-number-count">156</p>
              <p className="text-xs text-gray-500">Pending</p>
            </div>
            <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-3 text-center animate-fade-in-up transform hover:scale-[1.02] transition-all duration-300" style={{animationDelay: '0.3s'}}>
              <div className="w-8 h-8 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-2 animate-pulse-slow">
                <i className="ri-close-line text-red-600 text-sm"></i>
              </div>
              <p className="text-lg font-bold text-gray-800 animate-number-count">23</p>
              <p className="text-xs text-gray-500">Failed</p>
            </div>
          </div>
        </div>

        {/* Transaction List */}
        <div className="px-4">
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 animate-fade-in-up" style={{animationDelay: '0.4s'}}>
            <div className="p-4 border-b border-gray-100">
              <h3 className="font-semibold text-gray-800">All Transactions</h3>
            </div>
            <div className="divide-y divide-gray-100">
              {filteredTransactions.map((transaction, index) => (
                <div key={transaction.id} className="p-4 hover:bg-gray-50 transition-all duration-200 transform hover:scale-[1.01] animate-slide-in-left" style={{animationDelay: `${0.5 + index * 0.05}s`}}>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <div className={`w-10 h-10 rounded-full flex items-center justify-center animate-pulse-slow ${transaction.status === 'success' ? 'bg-green-100' : transaction.status === 'pending' ? 'bg-yellow-100' : 'bg-red-100'}`}>
                        <i className={transaction.status === 'success' ? 'ri-check-line text-green-600' : transaction.status === 'pending' ? 'ri-time-line text-yellow-600' : 'ri-close-line text-red-600'}></i>
                      </div>
                      <div>
                        <p className="font-medium text-gray-800">{transaction.receiver}</p>
                        <p className="text-sm text-gray-500">{transaction.method}</p>
                        <p className="text-xs text-gray-400">{transaction.time}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="font-bold text-gray-800">${transaction.amount}</p>
                      <span className={`text-xs px-2 py-1 rounded-full ${transaction.status === 'success' ? 'bg-green-100 text-green-700' : transaction.status === 'pending' ? 'bg-yellow-100 text-yellow-700' : 'bg-red-100 text-red-700'}`}>
                        {transaction.status}
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Pagination */}
          <div className="flex justify-center mt-6 animate-fade-in-up" style={{animationDelay: '0.8s'}}>
            <div className="flex space-x-2">
              <button className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-all duration-200 transform hover:scale-[1.02] !rounded-button">
                <i className="ri-arrow-left-line text-gray-600"></i>
              </button>
              <button className="px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-all duration-200 transform hover:scale-[1.02] !rounded-button">1</button>
              <button className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-all duration-200 transform hover:scale-[1.02] !rounded-button">2</button>
              <button className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-all duration-200 transform hover:scale-[1.02] !rounded-button">3</button>
              <button className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-all duration-200 transform hover:scale-[1.02] !rounded-button">
                <i className="ri-arrow-right-line text-gray-600"></i>
              </button>
            </div>
          </div>
        </div>
      </main>

      {/* Bottom Navigation */}
      <nav className="fixed bottom-0 w-full bg-white border-t border-gray-200 z-50 animate-slide-up">
        <div className="grid grid-cols-4 py-2">
          <Link href="/" className="flex flex-col items-center py-2 text-gray-400 hover:text-blue-500 transition-all duration-200 transform hover:scale-110">
            <div className="w-6 h-6 flex items-center justify-center mb-1">
              <i className="ri-dashboard-line text-xl"></i>
            </div>
            <span className="text-xs">Dashboard</span>
          </Link>
          <Link href="/transactions" className="flex flex-col items-center py-2 text-blue-600 transition-all duration-200 transform hover:scale-110">
            <div className="w-6 h-6 flex items-center justify-center mb-1">
              <i className="ri-exchange-fill text-xl"></i>
            </div>
            <span className="text-xs">Transactions</span>
          </Link>
          <Link href="/users" className="flex flex-col items-center py-2 text-gray-400 hover:text-blue-500 transition-all duration-200 transform hover:scale-110">
            <div className="w-6 h-6 flex items-center justify-center mb-1">
              <i className="ri-user-line text-xl"></i>
            </div>
            <span className="text-xs">Users</span>
          </Link>
          <Link href="/reports" className="flex flex-col items-center py-2 text-gray-400 hover:text-blue-500 transition-all duration-200 transform hover:scale-110">
            <div className="w-6 h-6 flex items-center justify-center mb-1">
              <i className="ri-bar-chart-line text-xl"></i>
            </div>
            <span className="text-xs">Reports</span>
          </Link>
        </div>
      </nav>

      <style jsx>{`
        @keyframes slide-down {
          from {
            transform: translateY(-100%);
            opacity: 0;
          }
          to {
            transform: translateY(0);
            opacity: 1;
          }
        }

        @keyframes slide-up {
          from {
            transform: translateY(100%);
            opacity: 0;
          }
          to {
            transform: translateY(0);
            opacity: 1;
          }
        }

        @keyframes fade-in-up {
          from {
            opacity: 0;
            transform: translateY(30px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }

        @keyframes slide-in-left {
          from {
            opacity: 0;
            transform: translateX(-30px);
          }
          to {
            opacity: 1;
            transform: translateX(0);
          }
        }

        @keyframes number-count {
          from {
            opacity: 0;
            transform: scale(0.8);
          }
          to {
            opacity: 1;
            transform: scale(1);
          }
        }

        .animate-slide-down {
          animation: slide-down 0.6s ease-out;
        }

        .animate-slide-up {
          animation: slide-up 0.6s ease-out;
        }

        .animate-fade-in-up {
          animation: fade-in-up 0.8s ease-out both;
        }

        .animate-slide-in-left {
          animation: slide-in-left 0.6s ease-out both;
        }

        .animate-number-count {
          animation: number-count 1s ease-out 0.5s both;
        }

        .animate-pulse-slow {
          animation: pulse 3s ease-in-out infinite;
        }

        @keyframes pulse {
          0%, 100% {
            transform: scale(1);
            opacity: 1;
          }
          50% {
            transform: scale(1.05);
            opacity: 0.9;
          }
        }
      `}</style>
    </div>
  );
}
