
'use client';

import Link from 'next/link';
import { useState } from 'react';

export default function UsersPage() {
  const [selectedTab, setSelectedTab] = useState('users');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedRole, setSelectedRole] = useState('all');

  const users = [
    { id: '1', name: 'Arjun Sharma', email: 'arjun@example.com', role: 'admin', status: 'active', lastLogin: '2 hours ago', totalTransactions: 45 },
    { id: '2', name: 'Priya Patel', email: 'priya@example.com', role: 'viewer', status: 'active', lastLogin: '1 day ago', totalTransactions: 23 },
    { id: '3', name: 'Rajesh Kumar', email: 'rajesh@example.com', role: 'admin', status: 'inactive', lastLogin: '3 days ago', totalTransactions: 67 },
    { id: '4', name: 'Sneha Gupta', email: 'sneha@example.com', role: 'viewer', status: 'active', lastLogin: '5 hours ago', totalTransactions: 12 },
    { id: '5', name: 'Vikram Singh', email: 'vikram@example.com', role: 'admin', status: 'active', lastLogin: '1 hour ago', totalTransactions: 89 },
    { id: '6', name: 'Anita Desai', email: 'anita@example.com', role: 'viewer', status: 'inactive', lastLogin: '1 week ago', totalTransactions: 34 },
    { id: '7', name: 'Rohit Verma', email: 'rohit@example.com', role: 'viewer', status: 'active', lastLogin: '30 min ago', totalTransactions: 56 },
    { id: '8', name: 'Kavya Nair', email: 'kavya@example.com', role: 'admin', status: 'active', lastLogin: '4 hours ago', totalTransactions: 78 },
  ];

  const getRoleColor = (role: string) => {
    switch (role) {
      case 'admin': return 'bg-purple-100 text-purple-800';
      case 'viewer': return 'bg-blue-100 text-blue-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-green-100 text-green-800';
      case 'inactive': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const filteredUsers = users.filter(user => {
    const matchesSearch = searchTerm === '' || 
      user.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      user.email.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesRole = selectedRole === 'all' || user.role === selectedRole;
    
    return matchesSearch && matchesRole;
  });

  const userStats = {
    total: users.length,
    active: users.filter(u => u.status === 'active').length,
    admins: users.filter(u => u.role === 'admin').length,
    viewers: users.filter(u => u.role === 'viewer').length
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="fixed top-0 w-full bg-white shadow-sm z-50">
        <div className="px-4 py-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Link href="/" className="w-8 h-8 flex items-center justify-center">
                <i className="ri-arrow-left-line text-gray-600 text-xl"></i>
              </Link>
              <h1 className="text-xl font-bold text-gray-800">Users</h1>
            </div>
            <Link href="/add-user" className="bg-blue-500 text-white px-4 py-2 rounded-lg text-sm font-medium !rounded-button">
              Add User
            </Link>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="pt-16 pb-20">
        {/* Stats Cards */}
        <div className="px-4 py-4">
          <div className="grid grid-cols-4 gap-3 mb-6">
            <div className="bg-white rounded-lg p-3 text-center shadow-sm border border-gray-100">
              <div className="text-2xl font-bold text-gray-800">{userStats.total}</div>
              <div className="text-xs text-gray-600">Total</div>
            </div>
            <div className="bg-white rounded-lg p-3 text-center shadow-sm border border-gray-100">
              <div className="text-2xl font-bold text-green-600">{userStats.active}</div>
              <div className="text-xs text-gray-600">Active</div>
            </div>
            <div className="bg-white rounded-lg p-3 text-center shadow-sm border border-gray-100">
              <div className="text-2xl font-bold text-purple-600">{userStats.admins}</div>
              <div className="text-xs text-gray-600">Admins</div>
            </div>
            <div className="bg-white rounded-lg p-3 text-center shadow-sm border border-gray-100">
              <div className="text-2xl font-bold text-blue-600">{userStats.viewers}</div>
              <div className="text-xs text-gray-600">Viewers</div>
            </div>
          </div>

          {/* Search and Filter */}
          <div className="bg-white rounded-xl p-4 shadow-sm border border-gray-100 mb-4">
            {/* Search Bar */}
            <div className="relative mb-4">
              <input
                type="text"
                placeholder="Search users..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-12 pr-4 py-3 bg-gray-50 rounded-lg text-sm border-none focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              <div className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 flex items-center justify-center">
                <i className="ri-search-line text-gray-400 text-lg"></i>
              </div>
            </div>

            {/* Role Filter */}
            <div className="flex space-x-2">
              <button
                onClick={() => setSelectedRole('all')}
                className={`px-3 py-1 rounded-full text-sm font-medium transition-colors ${selectedRole === 'all' ? 'bg-blue-500 text-white' : 'bg-gray-200 text-gray-600'}`}
              >
                All Roles
              </button>
              <button
                onClick={() => setSelectedRole('admin')}
                className={`px-3 py-1 rounded-full text-sm font-medium transition-colors ${selectedRole === 'admin' ? 'bg-blue-500 text-white' : 'bg-gray-200 text-gray-600'}`}
              >
                Admin
              </button>
              <button
                onClick={() => setSelectedRole('viewer')}
                className={`px-3 py-1 rounded-full text-sm font-medium transition-colors ${selectedRole === 'viewer' ? 'bg-blue-500 text-white' : 'bg-gray-200 text-gray-600'}`}
              >
                Viewer
              </button>
            </div>
          </div>

          {/* Users List */}
          <div className="space-y-3">
            {filteredUsers.map((user) => (
              <div key={user.id} className="bg-white rounded-xl p-4 shadow-sm border border-gray-100">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center space-x-3">
                    <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                      <i className="ri-user-line text-blue-600 text-xl"></i>
                    </div>
                    <div>
                      <h3 className="font-medium text-gray-800">{user.name}</h3>
                      <p className="text-sm text-gray-600">{user.email}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <span className={`text-xs px-2 py-1 rounded-full ${getRoleColor(user.role)}`}>
                      {user.role}
                    </span>
                    <div className="mt-1">
                      <span className={`text-xs px-2 py-1 rounded-full ${getStatusColor(user.status)}`}>
                        {user.status}
                      </span>
                    </div>
                  </div>
                </div>
                <div className="flex items-center justify-between text-sm text-gray-500">
                  <div className="flex items-center space-x-4">
                    <span className="flex items-center space-x-1">
                      <i className="ri-time-line text-xs"></i>
                      <span>{user.lastLogin}</span>
                    </span>
                    <span className="flex items-center space-x-1">
                      <i className="ri-exchange-line text-xs"></i>
                      <span>{user.totalTransactions} transactions</span>
                    </span>
                  </div>
                  <button className="text-blue-600 hover:text-blue-800">
                    <i className="ri-more-line text-lg"></i>
                  </button>
                </div>
              </div>
            ))}
          </div>

          {filteredUsers.length === 0 && (
            <div className="text-center py-12">
              <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="ri-user-line text-gray-400 text-2xl"></i>
              </div>
              <p className="text-gray-500">No users found</p>
            </div>
          )}
        </div>
      </main>

      {/* Bottom Navigation */}
      <nav className="fixed bottom-0 w-full bg-white border-t border-gray-200 z-50">
        <div className="grid grid-cols-4 py-2">
          <Link href="/" className="flex flex-col items-center py-2 text-gray-400">
            <div className="w-6 h-6 flex items-center justify-center mb-1">
              <i className="ri-dashboard-line text-xl"></i>
            </div>
            <span className="text-xs">Dashboard</span>
          </Link>
          <Link href="/transactions" className="flex flex-col items-center py-2 text-gray-400">
            <div className="w-6 h-6 flex items-center justify-center mb-1">
              <i className="ri-exchange-line text-xl"></i>
            </div>
            <span className="text-xs">Transactions</span>
          </Link>
          <button
            onClick={() => setSelectedTab('users')}
            className={`flex flex-col items-center py-2 ${selectedTab === 'users' ? 'text-blue-600' : 'text-gray-400'}`}
          >
            <div className="w-6 h-6 flex items-center justify-center mb-1">
              <i className="ri-user-line text-xl"></i>
            </div>
            <span className="text-xs">Users</span>
          </button>
          <Link href="/reports" className="flex flex-col items-center py-2 text-gray-400">
            <div className="w-6 h-6 flex items-center justify-center mb-1">
              <i className="ri-bar-chart-line text-xl"></i>
            </div>
            <span className="text-xs">Reports</span>
          </Link>
        </div>
      </nav>
    </div>
  );
}
